/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prak1;

/**
 *
 * @author RAMON
 */
import java.awt.BorderLayout;
import java.awt.Frame;
import javax.swing.*;

public class Prak1 extends JFrame{
    /**
     * @param args the command line arguments
     */
    JButton nbutton = new JButton("North");
    JButton sbutton = new JButton("South");
    JButton ebutton = new JButton("East");
    JButton wbutton = new JButton("West");
    JButton cbutton = new JButton("Center");
    
public Prak1() {
    super("Border Layout Beraksi");
    setSize(240,280);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());
        add (nbutton, BorderLayout.NORTH);
        add (sbutton, BorderLayout.SOUTH);
        add (ebutton, BorderLayout.EAST);
        add (wbutton, BorderLayout.WEST);
        add (cbutton, BorderLayout.CENTER);
}    
    public static void main(String[] args) {
        // TODO code application logic here
        Prak1 frame = new Prak1();
        frame.setVisible(true); 
    }
    
}
